



//
//  Drop Downlist.swift
//  View hirerchy
//
//  Created by weblue tech3 on 21/02/18.
//  Copyright © 2018 weblue tech3. All rights reserved.
//

import UIKit

class Drop_Downlist: UIViewController {
  
  //Mark: Outlets
  
  @IBOutlet var butttoCollection: [UIButton]!
  //Mark: Button Action
  
  @IBAction func dropDownAction(_ sender: UIButton) {
    
    butttoCollection.forEach{ (button) in
      
      UIView.animate(withDuration: 0.3, animations: {
        button.isHidden = !button.isHidden
        self.view.layoutIfNeeded()
      })
    }
  }
  
  @IBAction func buttonTapped(_ sender: UIButton) {
    guard let title = sender.currentTitle, let city = citys(rawValue :title) else{
      return
    }
    switch city {
    case .FirstButton:
      print("First")
    default:
      print("Four")
    }
    
  }
  
  //Mark:Variables
  
  enum citys:String {
    case FirstButton = "FirstButton"
    case FourButton = "Four Button"
  }
  
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
  }
  
}
