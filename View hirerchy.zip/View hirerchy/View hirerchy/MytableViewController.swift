//
//  MytableViewController.swift
//  View hirerchy
//
//  Created by weblue tech3 on 20/02/18.
//  Copyright © 2018 weblue tech3. All rights reserved.
//

import UIKit

class MytableViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource{
    @IBOutlet weak var tblView: UITableView!
    
    var image:[UIImage] = [#imageLiteral(resourceName: "img1"),#imageLiteral(resourceName: "img2"),#imageLiteral(resourceName: "img3"),#imageLiteral(resourceName: "img4"),#imageLiteral(resourceName: "img5")]
    let lbl1 = ["FirstImage","SecondImage","ThirdImage","FourImage","FiveImage"]
    let image2:UIImage = #imageLiteral(resourceName: "Jay-designstyle-cartoon-m")
   
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return image.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.labelNew.text = lbl1[indexPath.row]
        cell.imageSecond.image = image[indexPath.row]
            
        return cell
    }
    
    
}
