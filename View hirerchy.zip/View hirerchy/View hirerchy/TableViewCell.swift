//
//  TableViewCell.swift
//  View hirerchy
//
//  Created by weblue tech3 on 20/02/18.
//  Copyright © 2018 weblue tech3. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var labelNew: UILabel!
    @IBOutlet weak var imageSecond: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
