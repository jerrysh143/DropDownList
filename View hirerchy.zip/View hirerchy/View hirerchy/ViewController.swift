//
//  ViewController.swift
//  View hirerchy
//
//  Created by weblue tech3 on 19/02/18.
//  Copyright © 2018 weblue tech3. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    @IBOutlet weak var MyButton: UIButton!
    @IBOutlet weak var MyButttonnew: UIButton!
    
    var containerView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
      MyButton.layer.borderWidth = 1
        MyButton.layer.borderColor = UIColor.black.cgColor
        MyButttonnew.layer.borderWidth = 1
        MyButttonnew.layer.borderColor = UIColor.black.cgColor
    }
  

}
